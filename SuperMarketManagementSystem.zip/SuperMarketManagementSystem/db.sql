create database supermarket;
use supermarket;

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

INSERT INTO admin (uid, password) VALUES
('admin', 'admin');

CREATE TABLE seller (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    name VARCHAR(50) NOT NULL,
    gender varchar(10)
);

INSERT INTO seller (uid, password, name) VALUES
('seller', 'seller', 'name');

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    quantity INT,
    price DOUBLE,
    category VARCHAR(255)
);